#include <iostream>
using namespace std;

int main()
{
    int num = 7;

    if (num == 0) {
        cout << "The number is zero.";
    }
    else {
        cout << "The number is not zero.";
    }

    return 0;

}