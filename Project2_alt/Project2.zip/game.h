#include <string>

using namespace std;

struct Player
{
    string name = "";
    int age = 0;
    int strength = 0;
    int stamina = 0;
    int wisdom = 0;
    int pridePts = 0;

    int advisor = 0;
};

struct PlayerPosition
{
    int position;
    int path;
};

