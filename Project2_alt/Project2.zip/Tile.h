struct Tile
{
char color;
};