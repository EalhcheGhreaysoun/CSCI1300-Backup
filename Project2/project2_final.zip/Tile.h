struct Tile
{
    char color;
};