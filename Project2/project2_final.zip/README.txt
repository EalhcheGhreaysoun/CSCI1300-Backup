To run program, enter the following into a command line at the directory containing the project file:
g++ -Wall -Wpedantic -std=c++17 -g Board.cpp game.cpp project2.cpp
./a.out