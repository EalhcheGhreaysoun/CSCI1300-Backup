#include <iostream>

using namespace std;

int main() {
    cout << "Hello, world!";
    cout << " Hello CSCI 1300" << endl;
}